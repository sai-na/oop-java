public class manager extends employee{
	String department;
}
