public class officer extends employee{
	String specialisation;
}

