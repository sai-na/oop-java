public class employee{
	String name;
	int age;
	String number;
	String address;
	int salary;
	
	public void printsalary(){
		System.out.println("Salary is " +  salary);
	}
}
