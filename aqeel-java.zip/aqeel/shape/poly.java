class poly{
	public static void main(String[] args){
		triangle tr = new triangle();
		hexagon hx = new hexagon();
		rectangle rc = new rectangle();

		tr.noOfSides();
		hx.noOfSides();
		rc.noOfSides();
	}
}
