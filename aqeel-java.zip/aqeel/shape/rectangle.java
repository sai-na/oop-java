public class rectangle extends shape{
	void noOfSides(){
		System.out.println("Number of sides: 4");
	}
}
