public class triangle extends shape{
	void noOfSides(){
		System.out.println("Number of sides:  3");
	}
}
